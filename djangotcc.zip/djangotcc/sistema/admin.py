from django.contrib import admin
from .models import Aluno, SecretariaAcademica, Orientador, Monitor, Monitoria

admin.site.register(Aluno)
admin.site.register(SecretariaAcademica)
admin.site.register(Orientador)
admin.site.register(Monitor)
admin.site.register(Monitoria)

