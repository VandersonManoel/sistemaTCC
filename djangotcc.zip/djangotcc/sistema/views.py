from django.views.generic.base import TemplateView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic.list import ListView
from django.contrib.auth.models import User, Group
from django.urls import reverse_lazy
from .forms import AlunoForm, MonitorForm, OrientadorForm
from .models import SecretariaAcademica, Orientador, Monitor, Monitoria, AgendarMonitoria
from django.contrib.auth.mixins import LoginRequiredMixin
from braces.views import GroupRequiredMixin
from django.shortcuts import get_object_or_404


# Create View
class AlunoCreate(CreateView):
    template_name = 'cadastro.html'
    form_class = AlunoForm
    success_url = reverse_lazy('login')

    def form_valid(self, form):

        grupo = get_object_or_404(Group, name='Alunos')

        url = super().form_valid(form)

        self.object.groups.add(grupo)
        self.object.save()

        return url


class OrientadorCreate(GroupRequiredMixin, LoginRequiredMixin, CreateView):
    login_url = reverse_lazy('login')
    group_required = u'Secretaria Acadêmica'
    template_name = 'cadastro.html'
    form_class = OrientadorForm
    success_url = reverse_lazy('login')

    def form_valid(self, form):

        grupo = get_object_or_404(Group, name='Orientadores')

        url = super().form_valid(form)

        self.object.groups.add(grupo)
        self.object.save()

        return url


class MonitorCreate(GroupRequiredMixin, LoginRequiredMixin, CreateView):
    login_url = reverse_lazy('login')
    group_required = u'Secretaria Acadêmica'
    template_name = 'cadastro.html'
    form_class = MonitorForm
    success_url = reverse_lazy('monitor')

    def form_valid(self, form):

        grupo = get_object_or_404(Group, name='Monitores')

        url = super().form_valid(form)

        self.object.groups.add(grupo)
        self.object.save()

        return url

######### Monitoria (Monitor) #########


class MonitoriaCreate(GroupRequiredMixin, LoginRequiredMixin, CreateView):
    login_url = reverse_lazy('login')
    group_required = u'Alunos'
    model = Monitoria
    fields = ['disciplina', 'horario']
    template_name = 'addmonitoria.html'
    success_url = reverse_lazy('aluno')

    def form_valid(self, form):

        form.instance.usuario = self.request.user

        url = super().form_valid(form)

        return url


class MonitoriaUpdate(GroupRequiredMixin, LoginRequiredMixin, UpdateView):
    login_url = reverse_lazy('login')
    group_required = u'Alunos'
    model = Monitoria
    fields = ['disciplina', 'horario']
    template_name = 'atualizar-monitoria.html'
    success_url = reverse_lazy('lista-monitorias-monitor')


class MonitoriaDelete(GroupRequiredMixin, LoginRequiredMixin, DeleteView):
    login_url = reverse_lazy('login')
    group_required = u'Alunos'
    model = Monitoria
    template_name = 'excluir-monitoria.html'
    success_url = reverse_lazy('lista-monitorias-monitor')


class MonitoriaList(GroupRequiredMixin, LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    group_required = u'Alunos'
    model = Monitoria
    template_name = 'aluno.html'


# Template View

class PaginaInicialView(TemplateView):
    template_name = 'modelo.html'


# Monitoria (Aluno) ######### colocar os grupos ****

class AgendarMonitoriaCreate(LoginRequiredMixin, CreateView):
    login_url = reverse_lazy('login')
    model = AgendarMonitoria
    fields = ['assunto', 'observacao']
    template_name = 'addmonitoria.html'
    success_url = reverse_lazy('aluno')


class AgendarMonitoriaList(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    model = Monitoria
    template_name = 'lista-monitorias-aluno.html'


class MonitoriaAgendadasAlunoList(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    model = Monitoria
    template_name = 'lista-monitorias-agendadas-aluno.html'


class DetalhesMobitoriaAlunoList(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    model = AgendarMonitoria
    template_name = 'detalhes-monitoria-aluno.html'
