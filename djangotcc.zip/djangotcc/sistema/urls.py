from django.urls import path
from django.contrib.auth import views as auth_views
from .views import AlunoCreate, MonitorCreate, OrientadorCreate, MonitoriaCreate, AgendarMonitoriaCreate
from .views import PaginaInicialView
from .views import MonitoriaList, AgendarMonitoriaList, MonitoriaAgendadasAlunoList, DetalhesMobitoriaAlunoList
from .views import MonitoriaUpdate
from .views import MonitoriaDelete

urlpatterns = [

    path('', auth_views.LoginView.as_view(
        template_name='login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    #Cadastro - ALUNO
    path('cadastro/aluno/', AlunoCreate.as_view(), name='cadastro-aluno'),
    path('aluno1/', auth_views.LoginView.as_view(template_name='aluno.html'), name='aluno1'),

    #Cadastro - MONITOR
    path('cadastro/monitor/', MonitorCreate.as_view(), name='cadastro-monitor'),

    #Cadastro - ORIENTADOR
    path('cadastro/orientador/', OrientadorCreate.as_view(),
         name='cadastro-orientador'),

    ### Monitoria (Monitor) ###
    path('add-monitoria/', MonitoriaCreate.as_view(), name='add-monitoria'),
    path('monitorias/', MonitoriaList.as_view(),
         name='lista-monitorias-monitor'),
    path('atualizar/monitoria/<int:pk>/',
         MonitoriaUpdate.as_view(), name='atualizar-monitoria'),
    path('excluir/monitoria/<int:pk>/',
         MonitoriaDelete.as_view(), name='excluir-monitoria'),

    ### Monitoria (Aluno) ###
    path('agendar/monitoria/', AgendarMonitoriaCreate.as_view(),
         name='agendar-monitoria'),
    path('monitorias-do-dia/', AgendarMonitoriaList.as_view(),
         name='lista-monitorias-aluno'),
    path('aluno/', MonitoriaAgendadasAlunoList.as_view(),
         name='aluno'),
    path('detalhes-monitoria/aluno/', DetalhesMobitoriaAlunoList.as_view(),
         name='detalhes-monitoria-aluno'),



]
