from django.db import models
from django.contrib.auth.models import User

class Aluno(models.Model):
    nome = models.CharField(max_length=50)
    matricula = models.CharField(max_length=50)
    email = models.EmailField()
    senha = models.CharField(max_length=20)
    curso = models.CharField(max_length=50)

    def __str__(self):
        return 'Nome: {}, Matrícula: {}'.format(self.nome, self.matricula)


class SecretariaAcademica(models.Model):
    matricula = models.CharField(max_length=25)
    senha = models.CharField(max_length=20)

    def __str__(self):
        return 'Secretária Acadêmica - Matrícula: {}'.format(self.matricula)

class Orientador(models.Model):
    nome = models.CharField(max_length=50)
    matricula = models.CharField(max_length=50)
    email = models.EmailField()
    senha = models.CharField(max_length=20)
    curso = models.CharField(max_length=50)
    disciplina = models.CharField(max_length=30)
    secretaria = models.ForeignKey(SecretariaAcademica, on_delete=models.CASCADE, null=True)

    def __str__(self):
        return 'Nome: {}, Matrícula: {}'.format(self.nome, self.matricula)

class Monitor(models.Model):
    nome = models.CharField(max_length=50)
    matricula = models.CharField(max_length=50)
    email = models.EmailField()
    senha = models.CharField(max_length=20)
    curso = models.CharField(max_length=50)
    disciplina = models.CharField(max_length=30)
    secretaria = models.ForeignKey(SecretariaAcademica, on_delete=models.CASCADE, null=True)

    def __str__(self):
        return '{}'.format(self.nome)

class Monitoria(models.Model):
    disciplina = models.CharField(max_length=30)
    horario = models.TimeField()
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return 'Disciplina: {} - Horário: {} - Monitor: {}'.format(self.disciplina,  self.horario, self.monitor)

class AgendarMonitoria(models.Model):
    assunto = models.CharField(max_length=250)
    observacao = models.TextField()


    
    
